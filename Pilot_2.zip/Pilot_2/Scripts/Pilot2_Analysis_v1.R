#Install packages
install.packages("pacman")  
install.packages("ggpubr")
install.packages("tidyverse")
install.packages("dplyr")
install.packages("ggplot2")

# Load packages
library(ggpubr)
require(pacman)
library(dplyr)
library(ggplot2)
p_load('tidyverse', 'jsonlite', 'plyr', 'stargazer', 'DT', 'psych', 'writexl')

### ─────────────────────────────────────────────
### Load JSON data from JATOS export
### ─────────────────────────────────────────────
# Set the working directory to the folder where your data file lives
setwd("/Users/stephaniebugler/Documents/Masters/Masters Thesis/R/Pilot_2/Data")

# Read the file line-by-line and parse each JSON row into a data frame
dat <- suppressMessages(
  read_file("Pilot2_data.txt") %>%
    str_split("\n") %>%
    first() %>%
    discard(~ .x == "" || .x == "\r") %>%
    map_dfr(fromJSON, flatten = TRUE)
)

### ─────────────────────────────────────────────
### Assign unique ID to each participant
### ─────────────────────────────────────────────
dat$ID <- NA
tmp_IDcounter <- 0
for (i in 1:nrow(dat)) {
  if (!is.na(dat$sender[i]) && dat$sender[i] == "Greetings") {
    tmp_IDcounter <- tmp_IDcounter + 1
  }
  dat$ID[i] <- tmp_IDcounter
}
rm(tmp_IDcounter)



### ─────────────────────────────────────────────
### Calculate mean scores for Ecological Dimension
### ─────────────────────────────────────────────
# 1. Filter and select relevant columns
eco <- dat %>%
  filter(sender == "Ecological Dimension Scale") %>%
  select(ID, framingCondition, starts_with("EcologicalDimension"))

# 2. Convert to numeric
eco[ , 3:ncol(eco)] <- lapply(eco[ , 3:ncol(eco)], function(x) as.numeric(trimws(x)))

# 3. Compute participant-level mean score
eco_scores <- eco
eco_scores$eco_mean <- rowMeans(eco_scores[, grep("EcologicalDimension", names(eco_scores))], na.rm = TRUE)
eco_scores <- eco_scores[, c("ID", "framingCondition", "eco_mean")]

### ─────────────────────────────────────────────
### Calculate mean scores for Bioinspiration
### ─────────────────────────────────────────────
# 1. filter & selecr relevant columns
bio <- dat %>%
  filter(sender == "Bioinspiration Scale") %>%
  select(ID, framingCondition, starts_with("Bioinspiration"))

# 2. Convert char to numeric
bio[ , 3:ncol(bio)] <- lapply(bio[ , 3:ncol(bio)], function(x) as.numeric(trimws(x)))

# 3. Apply reverse coding for Bioinspiration scale items
bio <- bio %>%
  mutate(
    `Bioinspiration-VRtN4r` = 6 - `Bioinspiration-VRtN4r`,
    `Bioinspiration-PN2r`   = 6 - `Bioinspiration-PN2r`,
    `Bioinspiration-IPI2r`  = 6 - `Bioinspiration-IPI2r`
  )

# 4. Compute participant-level mean score
bio_scores <- bio
bio_scores$bio_mean <- rowMeans(bio_scores[, grep("Bioinspiration", names(bio_scores))], na.rm = TRUE)
bio_scores <- bio_scores[, c("ID", "framingCondition", "bio_mean")]

### ─────────────────────────────────────────────
### created framing info table from
### ─────────────────────────────────────────────
# Extract from 'InformedConsent' page
frame_info <- dat %>%
  filter(sender == "InformedConsent") %>%
  select(ID, framingCondition)

# Merge true condition into score tables
eco_scores <- left_join(eco_scores, frame_info, by = "ID") %>%
  select(-framingCondition.x) %>%
  dplyr::rename(framingCondition = framingCondition.y)

bio_scores <- left_join(bio_scores, frame_info, by = "ID") %>%
  select(-framingCondition.x) %>%
  dplyr::rename(framingCondition = framingCondition.y)

### ─────────────────────────────────────────────
### Export full response data to Excel
### ─────────────────────────────────────────────

# 1. Drop duplicate framingCondition columns
bio_clean <- bio %>% select(-framingCondition)
eco_clean <- eco %>% select(-framingCondition)

# 2. Merge scales by participant ID
combined <- full_join(bio_clean, eco_clean, by = "ID")

# 3. Merge correct framing condition
combined <- left_join(combined, frame_info, by = "ID") %>%
  relocate(ID, framingCondition)  # Optional: move to front

# 4. Export to Excel
library(writexl)
write_xlsx(combined, "combined_responses.xlsx")


### ─────────────────────────────────────────────
### Preview results
### ─────────────────────────────────────────────
#mean eco scores
head(eco_scores)
#mean bio scores
head(bio_scores)
#number of pps in each framing condition
table(eco_scores$framingCondition, useNA = "always")

### ─────────────────────────────────────────────
### Summary or Plot
### ─────────────────────────────────────────────
# Summary function
data_summary <- function(data, varname, groupnames){
  summary_func <- function(x, col){
    c(mean = mean(x[[col]], na.rm=TRUE),
      se = sd(x[[col]], na.rm=TRUE) / sqrt(length(na.omit(x[[col]]))))
  }
  data_sum <- ddply(data, groupnames, .fun=summary_func, varname)
  data_sum <- plyr::rename(data_sum, c("mean" = varname))
  return(data_sum)
}

# Summaries of scores by framing condition
data_summary(eco_scores, "eco_mean", "framingCondition")
data_summary(bio_scores, "bio_mean", "framingCondition")



# Interpretation of summary stats:
# * Sustainable framing leads to the highest ecological scores on average.
# * Sustainable framing produces the lowest bioinspiration scores.
# * Bioinspired framing leads to the highest bioinspiration scores.
# * Bioinspired framing results in the lowest ecological scores.


# Plots
ggplot(eco_scores, aes(x = framingCondition, y = eco_mean)) +
  geom_boxplot(fill = "lightgreen") +
  labs(title = "Ecological Dimension by Framing", y = "Mean Score") +
  theme_minimal()

ggplot(bio_scores, aes(x = framingCondition, y = bio_mean)) +
  geom_boxplot(fill = "skyblue") +
  labs(title = "Bioinspiration by Framing", y = "Mean Score") +
  theme_minimal()

# Woops I forgot about the neutral conditions... 
table(eco_scores$framingCondition, useNA = "always")

# Violin plot for Ecological Dimension
ggplot(eco_scores, aes(x = framingCondition, y = eco_mean)) +
  geom_violin(fill = "palegreen", alpha = 0.5, trim = FALSE) +
  geom_jitter(width = 0.15, alpha = 0.4, color = "darkgreen") +
  stat_summary(fun = mean, geom = "point", color = "black", size = 3) +
  labs(title = "Ecological Scores by Framing", y = "Mean Score", x = "Framing Condition") +
  theme_minimal()

# Violin plot for Bioinspiration
ggplot(bio_scores, aes(x = framingCondition, y = bio_mean)) +
  geom_violin(fill = "lightblue", alpha = 0.5, trim = FALSE) +
  geom_jitter(width = 0.15, alpha = 0.4, color = "darkblue") +
  stat_summary(fun = mean, geom = "point", color = "black", size = 3) +
  labs(title = "Bioinspiration Scores by Framing", y = "Mean Score", x = "Framing Condition") +
  theme_minimal()




### ─────────────────────────────────────────────
### test for spillover effects:
### ─────────────────────────────────────────────
# 1. Join pps bio inspiration and sustainability scores into one data frame
combined_scores <- left_join(bio_scores, eco_scores, by = c("ID", "framingCondition"))

#2. Run ANOVAs for spillover effects
#2a. Does framing affect Sustainability Scores?
eco_spillover <- aov(eco_mean ~ framingCondition, data = combined_scores)
summary(eco_spillover)
# 2a.2. Post-hoc comparision
TukeyHSD(eco_spillover)

#Visualise Framing effect on ecological scores
ggplot(combined_scores, aes(x = framingCondition, y = eco_mean, fill = framingCondition)) +
  geom_boxplot() +
  labs(title = "Spillover: Framing Effect on Ecological Scores",
       y = "Ecological Mean Score", x = "Framing Condition") +
  theme_minimal()

# Interpretation: Your sustainable vignette significantly boosted sustainability attitudes (as expected), but interestingly, bioinspired framing scored lowest on this scale.
# This shows strong domain specificity — and possibly a negative spillover.

#2b. Does framing affect bioinspiration scores?”
bio_spillover <- aov(bio_mean ~ framingCondition, data = combined_scores)
summary(bio_spillover)
TukeyHSD(bio_spillover)

#Visualise Framing effect on bioinpspiration scores
ggplot(combined_scores, aes(x = framingCondition, y = bio_mean, fill = framingCondition)) +
  geom_boxplot() +
  labs(title = "Spillover: Framing Effect on Bioinspiration Scores",
       y = "Bioinspiration Mean Score", x = "Framing Condition") +
  theme_minimal()

# Interpretation: Bioinspired vignettes significantly increased bioinspiration scale scores — just as designed.
# But again, sustainable framing actually reduced bioinspiration, suggesting minimal or even negative spillover in the other direction.




### ─────────────────────────────────────────────
### Performance of individual scale items:
### ─────────────────────────────────────────────
# 1. Convert to long format
#1a: Bioinspiration items
# Create clean frame_info first (1 row per participant)
frame_info <- dat %>%
  filter(sender == "InformedConsent") %>%
  select(ID, framingCondition) %>%
  distinct()


# Now join to bio_long
bio_long <- bio %>%
  pivot_longer(cols = starts_with("Bioinspiration"),
               names_to = "item", values_to = "score") %>%
  left_join(frame_info, by = "ID")

#rename the correct column
bio_long <- bio_long %>%
  select(-framingCondition.x) %>%
  dplyr::rename(framingCondition = framingCondition.y)


#2. Summarise by indivudal scale item & framing condition
#2a: Bioinspiration items
bio_item_summary <- bio_long %>%
  group_by(item, framingCondition) %>%
  dplyr::summarise(
    mean = mean(score, na.rm = TRUE),
    sd = sd(score, na.rm = TRUE),
    n = sum(!is.na(score)),
    se = sd / sqrt(n),
    .groups = "drop"
  )



#3a. Plot Bioinspiration Scale items by framing
ggplot(bio_item_summary, aes(x = reorder(item, -mean), y = mean, fill = framingCondition)) +
  geom_col(position = position_dodge(width = 0.8)) +
  geom_errorbar(aes(ymin = mean - se, ymax = mean + se),
                width = 0.2, position = position_dodge(width = 0.8)) +
  coord_flip() +
  labs(
    title = "Bioinspiration Items by Framing Condition",
    x = "Item",
    y = "Mean Score (1–5)"
  ) +
  theme_minimal() +
  theme(legend.position = "top")


# Same steps for the Ecological scale
# 1. Pivot ecological items to long format
eco_long <- eco_long %>%
  select(-framingCondition.x) %>%
  dplyr::rename(framingCondition = framingCondition.y)

#unload plyr to prevent package conflicts 
detach("package:plyr", unload=TRUE)


# summarise eco items
eco_item_summary <- eco_long %>%
  group_by(item, framingCondition) %>%
  dplyr::summarise(
    mean = mean(score, na.rm = TRUE),
    sd = sd(score, na.rm = TRUE),
    n = sum(!is.na(score)),
    se = sd / sqrt(n),
    .groups = "drop"
  )

#visualise eco items
ggplot(eco_item_summary, aes(x = reorder(item, -mean), y = mean, fill = framingCondition)) +
  geom_col(position = position_dodge(width = 0.8)) +
  geom_errorbar(aes(ymin = mean - se, ymax = mean + se),
                width = 0.2, position = position_dodge(width = 0.8)) +
  coord_flip() +
  labs(
    title = "Ecological Scale Items by Framing Condition",
    x = "Item", y = "Mean Score (1–7)"
  ) +
  theme_minimal() +
  theme(legend.position = "top")


### ─────────────────────────────────────────────
### Scale purification for bioinspiration items
### ─────────────────────────────────────────────

# 1. Reload Bioinspiration items
bio_items_clean <- dat %>%
  filter(sender == "Bioinspiration Scale") %>%
  select(starts_with("Bioinspiration"))

# 2. Convert all columns to numeric (trim whitespace just in case)
bio_items_clean <- bio_items_clean %>%
  mutate(across(everything(), ~ as.numeric(trimws(.))))

# 3. Reverse-code the 3 items
bio_items_clean <- bio_items_clean %>%
  mutate(
    `Bioinspiration-IPI2r` = 6 - `Bioinspiration-IPI2r`,
    `Bioinspiration-PN2r` = 6 - `Bioinspiration-PN2r`,
    `Bioinspiration-VRtN4r` = 6 - `Bioinspiration-VRtN4r`
  )



#2 compute Cronbach's Alpha (internal consistency analysis)
library(psych)
bio_alpha <- alpha(bio_items_clean)
print(bio_alpha$total$raw_alpha)
bio_alpha$item.stats

#Interpretation
# Total alpha = 0.887: very good internal consistency for the full 12-item Bioinspiration scale.
# item PN2r is hurting the scale (was negatively correlated with the total)
# "r-drop" is the Item-total correlation (lower = worse), r.drop < 0.30 is weak
# raw.r, std.r is the	correlation with total score. if they are Negative = likely misfit
# Optional: also drop (Optional) IPI2r: r.drop = 0.41, PN3: r.drop = 0.54, (less aligned than other items buts not critical)
# keep: Items with r.drop > 0.65 are solid contributors


